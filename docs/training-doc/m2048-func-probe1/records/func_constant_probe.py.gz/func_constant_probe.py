"""仅用于定位功能检查的JIT闭包问题；探索性诊断不替代正式提交后的V5重测。"""
import dataclasses
import pathlib
import sys
import numpy as np
ROOT=pathlib.Path("/scratch/hongze/robomme_policy_learning_MotionJEPA")
sys.path.insert(0,str(ROOT/"scripts/training/tests"))
from check_32frame_modul import require,exact,config,KEYS

def func(a):
    import jax
    import jax.numpy as jnp
    from flax import nnx
    import openpi.shared.array_typing as at
    from mme_vla_suite.training.config import get_config
    from openpi.models.model import restore_params
    from compatible_pi05_weights import merge_compatible
    from motion_gates_model import _obs_from_samples
    from _common import leaf_sha256
    sys.path.insert(0,str(ROOT/"scripts/assets"))
    import assets_lock
    lock=assets_lock.load_lock()
    assets_lock.require(["pi05_base"],level="full",lock=lock)
    c=dataclasses.replace(get_config("mme_vla_suite_b128_80k").model,history_config=config(a),
                          paligemma_variant="gemma_150m",action_expert_variant="gemma_300m")
    model=c.create(jax.random.key(42))
    initial=nnx.state(model,nnx.Param)
    path=ROOT/"v1-store/models/openpi-assets/checkpoints/pi05_base/params"
    merged,pretrained=merge_compatible(initial.to_pure_dict(),restore_params(path,restore_type=np.ndarray))
    pretrained.update(path=str(path.resolve()),asset=assets_lock.asset("pi05_base",lock))
    initial.replace_by_pure_dict(jax.tree.map(jnp.asarray,merged));nnx.update(model,initial)
    del initial,merged
    random=np.random.default_rng(42)
    sample={k:random.normal(0,.25,size=(2048,d)).astype(np.float32) for k,d in zip(KEYS[:3],(2048,768,8))}
    sample["static_mask"]=np.ones(2048,bool)
    full=_obs_from_samples([sample],motion=False)
    graph,trainable,frozen=nnx.split(model,nnx.All(nnx.Param,nnx.Not(c.get_freeze_filter())),...)
    rng=jax.random.key(7)

    def loss_fn(tp,fp,o):
        m=nnx.merge(graph,tp,fp)
        actions=jnp.asarray(np.random.default_rng(8).normal(size=(o.state.shape[0],20,32)).astype(np.float32))
        with at.disable_typechecking():
            return jnp.mean(m.compute_loss(rng,o,actions,train=False))
    loss_only=jax.jit(loss_fn)
    loss_grads=jax.jit(jax.value_and_grad(loss_fn,argnums=0))

    def digest(o):
        loss,gs=loss_grads(trainable,frozen,o)
        require(np.isfinite(float(loss)),"功能检验loss非有限")
        shas={}
        for p,v in jax.tree_util.tree_flatten_with_path(gs.to_pure_dict())[0]:
            arr=np.asarray(jax.device_get(v))
            require(np.isfinite(arr).all(),"功能检验梯度非有限")
            shas[jax.tree_util.keystr(p)]=leaf_sha256(arr)
        return float(loss),shas

    probes=[digest(full) for _ in range(3)]
    require(all(x[0].hex()==probes[0][0].hex() and x[1]==probes[0][1] for x in probes),"A/A非确定性：禁止排除梯度叶以凑通过")
    noise_floor=max(abs(x[0]-probes[0][0]) for x in probes)
    print(f"DETERMINISM=PASS probes=3 gradient_leaves={len(probes[0][1])} excluded=0",flush=True)

    def input_function(tp,fp,o,drop=False):
        def f(si,sp):
            if drop:
                keep=(jnp.arange(2048)%64 == 0)[None,:,None]
                si,sp=jnp.where(keep,si,0),jnp.where(keep,sp,0)
            return loss_fn(tp,fp,dataclasses.replace(o,static_image_emb=si,static_pos_emb=sp))
        return jax.grad(f,argnums=(0,1))(o.static_image_emb,o.static_pos_emb)
    input_normal=jax.jit(input_function)
    input_drop=jax.jit(lambda tp,fp,o:input_function(tp,fp,o,True))

    def token_table(o,gradients):
        tables=[]
        valid=np.asarray(o.static_mask)
        for grad in gradients:
            arr=np.asarray(grad,dtype=np.float32)
            require(np.isfinite(arr).all(),"输入梯度非有限")
            norm=np.linalg.norm(arr.astype(np.float64),axis=-1)
            tables.append(norm)
            if np.any(~valid):
                require(np.all(arr[~valid] == 0),"无效位置梯度泄漏")
        return tables
    full_norms=token_table(full,input_normal(trainable,frozen,full))
    require(all(np.all(t>0) for t in full_norms),"TOKEN_GRAD有位置未参与")
    print("TOKEN_GRAD=PASS tokens=2048 image_nonzero=2048 pos_nonzero=2048",flush=True)
    dropped=token_table(full,input_drop(trainable,frozen,full))
    require(all(np.count_nonzero(t) == 32 and np.all(t[:,::64]>0) for t in dropped),"故障注入没有隔离每帧63位置")
    require(not all(np.all(t>0) for t in dropped),"逐位置门未拒绝删token故障")
    print("TOKEN_DROP_NEGATIVE=PASS rejected=1 kept_per_band=1",flush=True)
    deltas=[]
    for band in range(32):
        changed=dataclasses.replace(full,static_image_emb=full.static_image_emb.at[:,band*64:(band+1)*64].add(.25))
        value=float(loss_only(trainable,frozen,changed))
        deltas.append(abs(value-probes[0][0]))
    require(all(d>noise_floor for d in deltas),"帧带扰动未全部超过A/A噪声")
    print(f"FRAME_BAND_PERTURB=PASS bands=32 above_noise=32 noise_floor={noise_floor} min_delta={min(deltas)}",flush=True)

    samples=[]
    for n in (1,8,31):
        samples.append({**sample,"static_mask":np.arange(2048)<n*64})
    short=_obs_from_samples(samples,motion=False)
    short_norms=token_table(short,input_normal(trainable,frozen,short))
    valid=np.asarray(short.static_mask)
    require(valid.any() and (~valid).any() and all(np.all(t[valid]>0) for t in short_norms),"短历史有效位置梯度为零")
    dirty={}
    for key in KEYS[:3]:
        arr=np.array(getattr(short,key));arr[~valid]=random.normal(0,1000,arr[~valid].shape)
        dirty[key]=jnp.asarray(arr)
    garbage=dataclasses.replace(short,**dirty)
    left,right=digest(short),digest(garbage)
    require(left[0].hex()==right[0].hex() and left[1]==right[1] and len(left[1])>0,"mask外垃圾改变loss或任一可训练梯度")
    @jax.jit
    def act(tp,fp,o):
        m=nnx.merge(graph,tp,fp)
        noise=jnp.asarray(np.random.default_rng(9).normal(size=(o.state.shape[0],20,32)).astype(np.float32))
        with at.disable_typechecking():
            return m.sample_actions(jax.random.key(3),o,noise=noise,num_steps=10)
    la,ra=np.asarray(act(trainable,frozen,short)),np.asarray(act(trainable,frozen,garbage))
    require(np.isfinite(la).all() and exact(la,ra),"mask外垃圾改变固定noise动作")
    changed=np.array(short.static_image_emb);changed[valid]=random.normal(0,1000,changed[valid].shape)
    negative=float(loss_only(trainable,frozen,dataclasses.replace(short,static_image_emb=jnp.asarray(changed))))
    require(negative != left[0],"有效位置垃圾负对照没有改变loss")
    print(f"MASK_SYNTH=PASS n_set=1,8,31 loss_bitexact=1 actions_bitexact=1 grad_sha_same={len(left[1])}/{len(left[1])} masked_grad_zero=1 valid_tokens_nonzero=1 negative_control_changed=1",flush=True)
    return {"full_token_norms":[t.tolist() for t in full_norms],"short_token_norms":[t.tolist() for t in short_norms],
            "band_deltas":deltas,"noise_floor":noise_floor,"loss":left[0],"gradient_shas":left[1],"pretrained":pretrained}



if __name__=="__main__":
    import argparse,json,time
    parser=argparse.ArgumentParser()
    parser.add_argument("--out",required=True)
    parser.add_argument("--history-config",default="perceptual-framesamp-modul-32frame-8x8.yaml")
    args=parser.parse_args()
    out=pathlib.Path(args.out)
    require(not out.exists(),"拒绝覆盖探索性结果")
    print("EXPLORATORY_ONLY=1 source_commit=0c877c7495dfe5db8b83f033442013c6d6fd8552",flush=True)
    started=time.time()
    result=func(args)
    out.write_text(json.dumps({"status":"EXPLORATORY_ONLY","seconds":time.time()-started,"result":result},ensure_ascii=False,indent=2)+"\n")

